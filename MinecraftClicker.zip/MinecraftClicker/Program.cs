namespace MinecraftClicker;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        if (args.Contains("--selftest", StringComparer.OrdinalIgnoreCase))
            return SelfTest.Run();

        using var mutex = new Mutex(true, @"Local\MinecraftClicker.SingleInstance", out bool isFirst);
        if (!isFirst)
        {
            MessageBox.Show("Программа уже запущена.", "Minecraft Clicker", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return 0;
        }

        try
        {
            ApplicationConfiguration.Initialize();
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);

            var store = new SettingsStore();
            var settings = store.Load();

            using var left = new ClickEngine(rightButton: false);
            using var right = new ClickEngine(rightButton: true);
            left.Apply(settings);
            right.Apply(settings);

            void ReleaseAll()
            {
                left.EmergencyRelease();
                right.EmergencyRelease();
            }

            // Safety nets: whatever happens, a virtual mouse button must not stay pressed.
            AppDomain.CurrentDomain.ProcessExit += (_, _) => ReleaseAll();
            AppDomain.CurrentDomain.UnhandledException += (_, e) =>
            {
                ReleaseAll();
                Logger.Write("Unhandled: " + e.ExceptionObject);
            };
            Application.ThreadException += (_, e) =>
            {
                ReleaseAll();
                Logger.Write("UI exception: " + e.Exception);
                MessageBox.Show("Внутренняя ошибка: " + e.Exception.Message, "Minecraft Clicker",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            using var hook = new InputHook(left, right);
            hook.Apply(settings);
            if (!hook.Start())
            {
                MessageBox.Show("Не удалось установить перехват мыши/клавиатуры. Подробности в %AppData%\\MinecraftClicker\\error.log",
                    "Minecraft Clicker", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }

            Application.Run(new MainForm(store, settings, left, right, hook));
            return 0;
        }
        finally
        {
            mutex.ReleaseMutex();
        }
    }
}
