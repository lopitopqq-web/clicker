using System.Text;

namespace MinecraftClicker;

/// <summary>
/// Decides whether the foreground window is the game: process name must match (javaw/java by default)
/// and, if keywords are configured, the window title must contain one of them (Minecraft/Badlion by default).
/// The result is cached per window handle for one second to keep the hook callback fast.
/// Thread-safe.
/// </summary>
internal sealed class FocusChecker
{
    private readonly object _gate = new();
    private string[] _processes = { "javaw", "java" };
    private string[] _titles = { "Minecraft", "Badlion" };
    private IntPtr _cachedWindow;
    private long _cachedAt;
    private bool _cachedResult;

    public void Update(string[] processes, string[] titleKeywords)
    {
        lock (_gate)
        {
            _processes = processes ?? Array.Empty<string>();
            _titles = titleKeywords ?? Array.Empty<string>();
            _cachedWindow = IntPtr.Zero;
        }
    }

    public bool IsMinecraftFocused()
    {
        IntPtr hwnd = Native.GetForegroundWindow();
        if (hwnd == IntPtr.Zero) return false; // no foreground window (lock screen, secure desktop, ...)

        long now = Environment.TickCount64;
        lock (_gate)
        {
            if (hwnd == _cachedWindow && now - _cachedAt < 1000) return _cachedResult;
            bool result = Evaluate(hwnd);
            _cachedWindow = hwnd;
            _cachedAt = now;
            _cachedResult = result;
            return result;
        }
    }

    private bool Evaluate(IntPtr hwnd)
    {
        try
        {
            Native.GetWindowThreadProcessId(hwnd, out uint pid);
            if (pid == 0) return false;

            string? name = GetProcessName(pid);
            if (name is null) return false;
            if (!_processes.Any(p => string.Equals(p, name, StringComparison.OrdinalIgnoreCase))) return false;

            if (_titles.Length == 0) return true;
            var sb = new StringBuilder(256);
            Native.GetWindowText(hwnd, sb, sb.Capacity);
            string title = sb.ToString();
            return _titles.Any(k => title.Contains(k, StringComparison.OrdinalIgnoreCase));
        }
        catch
        {
            return false;
        }
    }

    private static string? GetProcessName(uint pid)
    {
        IntPtr h = Native.OpenProcess(Native.PROCESS_QUERY_LIMITED_INFORMATION, false, pid);
        if (h == IntPtr.Zero) return null;
        try
        {
            var sb = new StringBuilder(1024);
            uint size = (uint)sb.Capacity;
            return Native.QueryFullProcessImageName(h, 0, sb, ref size)
                ? Path.GetFileNameWithoutExtension(sb.ToString())
                : null;
        }
        finally
        {
            Native.CloseHandle(h);
        }
    }
}
