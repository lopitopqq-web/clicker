using System.Text.Json;
using System.Text.Json.Serialization;

namespace MinecraftClicker;

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum BindingKind { Mouse, Key }

/// <summary>
/// Activation button. Mouse codes: 1 = side button 1 (back), 2 = side button 2 (forward), 3 = middle button.
/// Key codes are Windows virtual-key codes.
/// </summary>
public sealed record ActivationBinding(BindingKind Kind, int Code)
{
    public static readonly ActivationBinding Default = new(BindingKind.Mouse, 1);

    [JsonIgnore]
    public bool IsValid => Kind switch
    {
        BindingKind.Mouse => Code is >= 1 and <= 3,
        BindingKind.Key => Code is >= 1 and <= 254 && Code != 0x1B, // Esc is reserved for cancelling capture
        _ => false
    };

    [JsonIgnore]
    public string DisplayName => Kind switch
    {
        BindingKind.Mouse => Code switch
        {
            1 => "MOUSE4",
            2 => "MOUSE5",
            3 => "MOUSE3",
            _ => $"MOUSE{Code}"
        },
        _ => ((System.Windows.Forms.Keys)Code).ToString().ToUpperInvariant()
    };
}

public sealed class AppSettings
{
    public const double MinAllowedCps = 1;
    public const double MaxAllowedCps = 50;
    public const double MinHoldMs = 0.1;
    public const double MaxHoldMs = 50;

    public double MinCps { get; set; } = 17;
    public double MaxCps { get; set; } = 20;
    public ActivationBinding Binding { get; set; } = ActivationBinding.Default;
    public bool LeftToggle { get; set; } = false; // true: press once to start, press again to stop

    // How long the left button stays pressed per click, in ms. Independent of CPS / the interval between clicks.
    // 0.1 is the minimum and the equivalent of "Click Duty Cycle 0%": the game receives the click but practically
    // never sees the button held, so it does not start interacting with the block under the crosshair.
    public double LeftHoldMs { get; set; } = 0.2;

    // Right mouse button clicker (independent range and activation button).
    public double RightMinCps { get; set; } = 17;
    public double RightMaxCps { get; set; } = 20;
    public ActivationBinding RightBinding { get; set; } = new(BindingKind.Mouse, 2);
    public bool RightToggle { get; set; } = false;

    // Advanced (edit settings.json): clicks only while a matching window is in the foreground.
    public bool RequireMinecraftFocus { get; set; } = true;
    public string[] ProcessNames { get; set; } = { "javaw", "java" };
    public string[] WindowTitleKeywords { get; set; } = { "Minecraft", "Badlion" };

    /// <summary>Returns an error message, or null if the settings are valid.</summary>
    public string? Validate()
    {
        if (double.IsNaN(MinCps) || double.IsNaN(MaxCps) || double.IsInfinity(MinCps) || double.IsInfinity(MaxCps))
            return "Некорректное значение CPS";
        if (MinCps < MinAllowedCps || MinCps > MaxAllowedCps)
            return $"Мин. CPS должен быть от {MinAllowedCps} до {MaxAllowedCps}";
        if (MaxCps < MinAllowedCps || MaxCps > MaxAllowedCps)
            return $"Макс. CPS должен быть от {MinAllowedCps} до {MaxAllowedCps}";
        if (MinCps > MaxCps)
            return "Мин. CPS не может быть больше макс. CPS";
        if (Binding is null || !Binding.IsValid)
            return "Некорректная клавиша активации ЛКМ";
        if (double.IsNaN(LeftHoldMs) || LeftHoldMs < MinHoldMs || LeftHoldMs > MaxHoldMs)
            return $"Удержание ЛКМ должно быть от {MinHoldMs} до {MaxHoldMs} мс";

        if (double.IsNaN(RightMinCps) || double.IsNaN(RightMaxCps) || double.IsInfinity(RightMinCps) || double.IsInfinity(RightMaxCps))
            return "Некорректное значение CPS для ПКМ";
        if (RightMinCps < MinAllowedCps || RightMinCps > MaxAllowedCps || RightMaxCps < MinAllowedCps || RightMaxCps > MaxAllowedCps)
            return $"CPS для ПКМ должен быть от {MinAllowedCps} до {MaxAllowedCps}";
        if (RightMinCps > RightMaxCps)
            return "ПКМ: мин. CPS не может быть больше макс. CPS";
        if (RightBinding is null || !RightBinding.IsValid)
            return "Некорректная клавиша активации ПКМ";
        if (RightBinding == Binding)
            return "Кнопки активации ЛКМ и ПКМ должны быть разными";
        if (ProcessNames is null || WindowTitleKeywords is null)
            return "Некорректный список окон";
        return null;
    }
}

public sealed class SettingsStore
{
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public string FilePath { get; }

    public SettingsStore(string? filePath = null)
    {
        FilePath = filePath ?? Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "MinecraftClicker", "settings.json");
    }

    /// <summary>Loads settings; any missing/corrupt/invalid file yields defaults.</summary>
    public AppSettings Load()
    {
        try
        {
            if (!File.Exists(FilePath)) return new AppSettings();
            var s = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath), Options);
            if (s is null) return new AppSettings();
            ResolveBindingConflict(s);
            return s.Validate() is null ? s : new AppSettings();
        }
        catch (Exception ex)
        {
            Logger.Write("Settings load failed: " + ex.Message);
            return new AppSettings();
        }
    }

    /// <summary>
    /// A settings file from before the right-button clicker existed (or a hand edit) may leave both buttons on the
    /// same activation button; pick the first free default for the right one instead of discarding everything.
    /// </summary>
    internal static void ResolveBindingConflict(AppSettings s)
    {
        if (s.Binding is null) return;
        if (s.RightBinding is not null && s.RightBinding != s.Binding) return;

        var candidates = new[]
        {
            new ActivationBinding(BindingKind.Mouse, 2),
            new ActivationBinding(BindingKind.Mouse, 1),
            new ActivationBinding(BindingKind.Mouse, 3)
        };
        s.RightBinding = candidates.First(c => c != s.Binding);
    }

    /// <summary>Atomic save (temp file + replace). Throws on invalid settings or I/O errors.</summary>
    public void Save(AppSettings settings)
    {
        var error = settings.Validate();
        if (error is not null) throw new ArgumentException(error);

        var dir = Path.GetDirectoryName(FilePath);
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

        var tmp = FilePath + ".tmp";
        File.WriteAllText(tmp, JsonSerializer.Serialize(settings, Options));
        File.Move(tmp, FilePath, overwrite: true);
    }
}

internal static class Logger
{
    private static readonly object Gate = new();

    public static void Write(string message)
    {
        try
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MinecraftClicker");
            Directory.CreateDirectory(dir);
            var file = Path.Combine(dir, "error.log");
            lock (Gate)
            {
                if (File.Exists(file) && new FileInfo(file).Length > 256 * 1024) File.Delete(file);
                File.AppendAllText(file, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} {message}{Environment.NewLine}");
            }
        }
        catch
        {
            // logging must never throw
        }
    }
}
