@echo off
setlocal
cd /d "%~dp0"

where dotnet >nul 2>nul
if errorlevel 1 (
    echo .NET 8 SDK not found. Install it from https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit /b 1
)

echo Building self-contained single-file EXE...
dotnet publish MinecraftClicker.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o publish
if errorlevel 1 (
    echo.
    echo BUILD FAILED. Copy the errors above and send them back for a fix.
    pause
    exit /b 1
)

echo.
echo Running self-test...
"publish\MinecraftClicker.exe" --selftest
echo Self-test exit code: %errorlevel%  (0 = all checks passed, details in publish\selftest.txt)

echo.
echo Done: %~dp0publish\MinecraftClicker.exe
pause
