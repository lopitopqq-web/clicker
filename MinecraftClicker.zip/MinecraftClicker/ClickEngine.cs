using System.Diagnostics;
using System.Runtime.InteropServices;

namespace MinecraftClicker;

internal sealed record EngineConfig(double MinCps, double MaxCps, bool RequireFocus, double? FixedHoldMs);

/// <summary>
/// Waits for a duration using a high-resolution waitable timer (Windows 10 1803+), and can be interrupted
/// through a stop handle. Falls back to a normal waitable timer + timeBeginPeriod(1) on older systems.
/// </summary>
internal sealed class PreciseTimer : IDisposable
{
    private IntPtr _timer;
    private readonly IntPtr[] _handles = new IntPtr[2];
    private readonly bool _usesTimePeriod;

    public bool HighResolution { get; }

    public PreciseTimer(IntPtr stopHandle)
    {
        _timer = Native.CreateWaitableTimerEx(IntPtr.Zero, null,
            Native.CREATE_WAITABLE_TIMER_HIGH_RESOLUTION, Native.TIMER_ALL_ACCESS);
        HighResolution = _timer != IntPtr.Zero;

        if (_timer == IntPtr.Zero)
        {
            _timer = Native.CreateWaitableTimerEx(IntPtr.Zero, null, 0, Native.TIMER_ALL_ACCESS);
            if (_timer == IntPtr.Zero) throw new InvalidOperationException("CreateWaitableTimerEx failed");
            Native.timeBeginPeriod(1);
            _usesTimePeriod = true;
        }

        _handles[0] = _timer;
        _handles[1] = stopHandle;
    }

    /// <summary>Returns true when the time elapsed, false when the stop handle was signalled (or on error).</summary>
    public bool Wait(double milliseconds, out bool stopped)
    {
        long due = -(long)(milliseconds * 10_000.0); // negative = relative, 100 ns units
        if (due >= 0) due = -1;

        stopped = false;
        if (!Native.SetWaitableTimer(_timer, ref due, 0, IntPtr.Zero, IntPtr.Zero, false)) return false;
        uint r = Native.WaitForMultipleObjects(2, _handles, false, Native.INFINITE);
        if (r == Native.WAIT_OBJECT_0) return true;
        stopped = r == Native.WAIT_OBJECT_0 + 1;
        return false;
    }

    public void Dispose()
    {
        if (_timer != IntPtr.Zero)
        {
            Native.CloseHandle(_timer);
            _timer = IntPtr.Zero;
        }
        if (_usesTimePeriod) Native.timeEndPeriod(1);
    }
}

/// <summary>
/// Sends virtual LMB (or RMB) clicks from one dedicated background thread while a session is active.
/// Start() is idempotent (only one click loop can exist), Stop() ends the loop immediately,
/// and the virtual button is always released in a finally block / on dispose / on emergency release.
/// </summary>
internal sealed class ClickEngine : IDisposable
{
    private static readonly int InputSize = Marshal.SizeOf<Native.INPUT>();

    private readonly AutoResetEvent _startSignal = new(false);
    private readonly ManualResetEvent _stopEvent = new(false);
    private readonly ManualResetEvent _exitEvent = new(false);
    private readonly FocusChecker _focus = new();
    private readonly IntervalGenerator _generator = new();
    private readonly PreciseTimer _timer;
    private readonly Thread _thread;
    private readonly bool _right;
    private readonly Native.INPUT[] _downInput;
    private readonly Native.INPUT[] _upInput;

    private volatile EngineConfig _config = new(17, 20, true, null);
    private int _active;   // 0 = idle, 1 = a click loop is running (or about to run)
    private int _lmbDown;  // 1 while the virtual LMB is pressed
    private bool _disposed;

    /// <param name="rightButton">false = left mouse button, true = right mouse button</param>
    public ClickEngine(bool rightButton = false)
    {
        _right = rightButton;
        _downInput = new[] { MakeInput(rightButton ? Native.MOUSEEVENTF_RIGHTDOWN : Native.MOUSEEVENTF_LEFTDOWN) };
        _upInput = new[] { MakeInput(rightButton ? Native.MOUSEEVENTF_RIGHTUP : Native.MOUSEEVENTF_LEFTUP) };
        _timer = new PreciseTimer(_stopEvent.SafeWaitHandle.DangerousGetHandle());
        _thread = new Thread(WorkerMain)
        {
            IsBackground = true,
            Name = rightButton ? "ClickEngine-RMB" : "ClickEngine-LMB",
            Priority = ThreadPriority.AboveNormal
        };
        _thread.Start();
    }

    /// <summary>True while a click session is running (shown as Status in the UI).</summary>
    public bool IsActive => Volatile.Read(ref _active) == 1;

    public void Apply(AppSettings settings)
    {
        _focus.Update(settings.ProcessNames, settings.WindowTitleKeywords);
        _config = _right
            ? new EngineConfig(settings.RightMinCps, settings.RightMaxCps, settings.RequireMinecraftFocus, null)
            : new EngineConfig(settings.MinCps, settings.MaxCps, settings.RequireMinecraftFocus, settings.LeftHoldMs);
    }

    /// <summary>Begins clicking. Returns false if disposed or a loop is already active.</summary>
    public bool Start()
    {
        if (_disposed) return false;
        if (Interlocked.CompareExchange(ref _active, 1, 0) != 0) return false;
        _stopEvent.Reset();
        _startSignal.Set();
        return true;
    }

    /// <summary>Stops clicking; the virtual LMB is released by the worker thread right away.</summary>
    public void Stop() => _stopEvent.Set();

    /// <summary>Last-resort release usable from any thread (crash handlers, process exit).</summary>
    public void EmergencyRelease()
    {
        try { _stopEvent.Set(); } catch { }
        try { ReleaseLmb(); } catch { }
    }

    private void WorkerMain()
    {
        var handles = new WaitHandle[] { _startSignal, _exitEvent };
        while (true)
        {
            int which = WaitHandle.WaitAny(handles);
            if (which == 1) break;

            try
            {
                ClickLoop();
            }
            catch (Exception ex)
            {
                Logger.Write("Click loop failed: " + ex);
            }
            finally
            {
                ReleaseLmb();
                Volatile.Write(ref _active, 0);
            }
        }
        ReleaseLmb();
    }

    private void ClickLoop()
    {
        EngineConfig? applied = null;
        bool needBurst = true;

        while (!_stopEvent.WaitOne(0))
        {
            var cfg = _config;
            if (!ReferenceEquals(cfg, applied))
            {
                _generator.Configure(cfg.MinCps, cfg.MaxCps);
                applied = cfg;
            }

            if (cfg.RequireFocus && !_focus.IsMinecraftFocused()) break; // focus lost -> stop the session

            if (needBurst)
            {
                _generator.BeginBurst(); // sharp start of the session
                needBurst = false;
            }

            double interval = _generator.Next();
            double hold = cfg.FixedHoldMs is double holdMs
                ? _generator.NextPulse(holdMs, interval) // LMB: press length set separately from the interval
                : _generator.NextHold(interval);         // RMB: unchanged (random share of the interval)

            long t0 = Stopwatch.GetTimestamp();

            Volatile.Write(ref _lmbDown, 1);
            if (!Send(down: true)) throw new InvalidOperationException("SendInput(button down) failed, error " + Marshal.GetLastWin32Error());
            long tDown = Stopwatch.GetTimestamp(); // the hold is measured after the press was really sent

            if (!WaitUntil(tDown + ToTicks(hold))) break;
            ReleaseLmb();
            if (!WaitUntil(t0 + ToTicks(interval))) break;
        }
    }

    /// <summary>Waits until the given timestamp. Returns false if a stop was requested.</summary>
    private bool WaitUntil(long target)
    {
        double remainingMs = (target - Stopwatch.GetTimestamp()) * 1000.0 / Stopwatch.Frequency;
        double spinMs = _timer.HighResolution ? 0.8 : 2.0;

        if (remainingMs > spinMs + 0.2)
        {
            if (!_timer.Wait(remainingMs - spinMs, out bool stopped))
            {
                if (stopped) return false;
                // timer error: fall back to spinning for the rest of the interval
            }
        }

        while (Stopwatch.GetTimestamp() < target) Thread.SpinWait(30);
        return !_stopEvent.WaitOne(0);
    }

    private static long ToTicks(double ms) => (long)(ms * Stopwatch.Frequency / 1000.0);

    private void ReleaseLmb()
    {
        if (Interlocked.Exchange(ref _lmbDown, 0) == 1)
        {
            if (!Send(down: false)) Send(down: false); // one retry
        }
    }

    private bool Send(bool down) =>
        Native.SendInput(1, down ? _downInput : _upInput, InputSize) == 1;

    private static Native.INPUT MakeInput(uint flags) => new()
    {
        type = Native.INPUT_MOUSE,
        u = new Native.InputUnion { mi = new Native.MOUSEINPUT { dwFlags = flags } }
    };

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        _stopEvent.Set();
        _exitEvent.Set();
        if (!_thread.Join(2000)) Logger.Write("ClickEngine thread did not exit in time");

        ReleaseLmb();
        _timer.Dispose();
        _startSignal.Dispose();
        _stopEvent.Dispose();
        _exitEvent.Dispose();
    }
}
