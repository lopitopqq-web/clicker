using System.Drawing.Drawing2D;

namespace MinecraftClicker;

/// <summary>Small on/off switch (pill with a knob), like the Toggle in the reference UI.</summary>
internal sealed class SwitchControl : Control
{
    private bool _checked;

    public event EventHandler? CheckedChanged;

    public SwitchControl()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        Size = new Size(50, 24);
        Cursor = Cursors.Hand;
    }

    public bool Checked
    {
        get => _checked;
        set
        {
            if (_checked == value) return;
            _checked = value;
            Invalidate();
            CheckedChanged?.Invoke(this, EventArgs.Empty);
        }
    }

    protected override void OnClick(EventArgs e)
    {
        base.OnClick(e);
        Checked = !Checked;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.Clear(Parent?.BackColor ?? BackColor);

        var rect = new Rectangle(0, 0, Width - 1, Height - 1);
        using var path = RoundedRect(rect, Height / 2);
        using var track = new SolidBrush(_checked ? Color.FromArgb(46, 110, 220) : Color.FromArgb(34, 40, 50));
        g.FillPath(track, path);

        int d = Height - 6;
        int x = _checked ? Width - d - 3 : 3;
        using var knob = new SolidBrush(_checked ? Color.White : Color.FromArgb(150, 158, 170));
        g.FillEllipse(knob, x, 3, d, d);
    }

    private static GraphicsPath RoundedRect(Rectangle r, int radius)
    {
        int d = radius * 2;
        var p = new GraphicsPath();
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }
}

/// <summary>
/// Compact dark UI modelled on the reference clicker: Left / Right tabs, each with CPS, Jitter, Button, Toggle, Status.
/// (Left also has the press duration.) Changes are applied and saved automatically a moment after the last edit.
/// CPS and Jitter map onto the engine's range: min = CPS * (1 - Jitter), max = CPS * (1 + Jitter).
/// </summary>
internal sealed class MainForm : Form
{
    private static readonly Color Bg = Color.FromArgb(14, 19, 25);
    private static readonly Color PanelBg = Color.FromArgb(13, 17, 23);
    private static readonly Color Field = Color.FromArgb(24, 30, 38);
    private static readonly Color Fg = Color.FromArgb(210, 217, 226);
    private static readonly Color Muted = Color.FromArgb(130, 140, 152);
    private static readonly Color TabActive = Color.FromArgb(30, 39, 52);
    private static readonly Color TabIdle = Color.FromArgb(17, 22, 29);
    private static readonly Color Green = Color.FromArgb(63, 185, 80);
    private static readonly Color Error = Color.FromArgb(240, 100, 100);

    private sealed class ChannelUi
    {
        public readonly Panel Panel = new();
        public readonly NumericUpDown Cps = new();
        public readonly NumericUpDown Jitter = new();
        public readonly NumericUpDown Hold = new(); // used on the Left tab only
        public readonly Button Bind = new();
        public readonly SwitchControl Toggle = new();
        public readonly Label Status = new();
        public ActivationBinding Binding = ActivationBinding.Default;
    }

    private readonly SettingsStore _store;
    private readonly ClickEngine _leftEngine;
    private readonly ClickEngine _rightEngine;
    private readonly InputHook _hook;

    private readonly ChannelUi _left = new();
    private readonly ChannelUi _right = new();
    private readonly Button _tabLeft = new();
    private readonly Button _tabRight = new();
    private readonly Label _msg = new();
    private readonly System.Windows.Forms.Timer _saveTimer = new() { Interval = 500 };
    private readonly System.Windows.Forms.Timer _statusTimer = new() { Interval = 100 };
    private readonly ToolTip _tips = new();

    private AppSettings _current;
    private int _capturingChannel = -1; // -1 none, 0 left, 1 right

    public MainForm(SettingsStore store, AppSettings settings, ClickEngine leftEngine, ClickEngine rightEngine, InputHook hook)
    {
        _store = store;
        _leftEngine = leftEngine;
        _rightEngine = rightEngine;
        _hook = hook;
        _current = settings;

        AutoScaleMode = AutoScaleMode.Dpi;
        AutoScaleDimensions = new SizeF(96f, 96f);
        Text = "Minecraft Clicker";
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(420, 328);
        BackColor = Bg;
        ForeColor = Fg;
        Font = new Font("Consolas", 10f);

        SetupTab(_tabLeft, "Left", 14);
        SetupTab(_tabRight, "Right", 210);
        _tabLeft.Click += (_, _) => ShowTab(0);
        _tabRight.Click += (_, _) => ShowTab(1);

        BuildPanel(_left, settings.MinCps, settings.MaxCps, settings.Binding, settings.LeftToggle, settings.LeftHoldMs, 0);
        BuildPanel(_right, settings.RightMinCps, settings.RightMaxCps, settings.RightBinding, settings.RightToggle, null, 1);

        _msg.SetBounds(16, 300, 388, 22);
        _msg.ForeColor = Muted;
        _msg.TextAlign = ContentAlignment.MiddleLeft;

        Controls.Add(_tabLeft);
        Controls.Add(_tabRight);
        Controls.Add(_left.Panel);
        Controls.Add(_right.Panel);
        Controls.Add(_msg);
        ShowTab(0);

        foreach (var ui in new[] { _left, _right })
        {
            ui.Cps.ValueChanged += (_, _) => QueueSave();
            ui.Jitter.ValueChanged += (_, _) => QueueSave();
            ui.Toggle.CheckedChanged += (_, _) => QueueSave();
        }
        _left.Hold.ValueChanged += (_, _) => QueueSave();

        _saveTimer.Tick += (_, _) =>
        {
            _saveTimer.Stop();
            ApplyAndSave();
        };
        _statusTimer.Tick += (_, _) => UpdateStatus();
        _statusTimer.Start();

        FormClosing += OnFormClosing;
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        int dark = 1;
        Native.DwmSetWindowAttribute(Handle, 20, ref dark, sizeof(int)); // DWMWA_USE_IMMERSIVE_DARK_MODE
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _saveTimer.Dispose();
            _statusTimer.Dispose();
            _tips.Dispose();
        }
        base.Dispose(disposing);
    }

    // ---------------------------------------------------------------- layout

    private void SetupTab(Button tab, string text, int x)
    {
        tab.SetBounds(x, 12, 196, 32);
        tab.Text = text;
        tab.FlatStyle = FlatStyle.Flat;
        tab.FlatAppearance.BorderSize = 0;
        tab.FlatAppearance.MouseOverBackColor = TabActive;
        tab.FlatAppearance.MouseDownBackColor = TabActive;
        tab.ForeColor = Fg;
        tab.UseVisualStyleBackColor = false;
        tab.Cursor = Cursors.Hand;
    }

    private void ShowTab(int index)
    {
        _left.Panel.Visible = index == 0;
        _right.Panel.Visible = index == 1;
        _tabLeft.BackColor = index == 0 ? TabActive : TabIdle;
        _tabRight.BackColor = index == 1 ? TabActive : TabIdle;
    }

    private void BuildPanel(ChannelUi ui, double minCps, double maxCps, ActivationBinding binding, bool toggle, double? holdMs, int channel)
    {
        ui.Binding = binding;
        ui.Panel.SetBounds(14, 52, 392, 240);
        ui.Panel.BackColor = PanelBg;

        decimal cps = Math.Round((decimal)((minCps + maxCps) / 2.0), 2);
        decimal jitter = minCps + maxCps > 0
            ? Math.Round((decimal)((maxCps - minCps) / (maxCps + minCps) * 100.0), 1)
            : 0m;

        int y = 16;

        AddLabel(ui.Panel, "CPS", y);
        SetupNumeric(ui.Cps, 266, y, 116, cps, 1m, 50m, 2, 0.5m);
        ui.Panel.Controls.Add(ui.Cps);
        y += 38;

        AddLabel(ui.Panel, "Jitter, %", y);
        SetupNumeric(ui.Jitter, 266, y, 116, jitter, 0m, 50m, 1, 1m);
        ui.Panel.Controls.Add(ui.Jitter);
        _tips.SetToolTip(ui.Jitter, "Разброс темпа вокруг CPS: диапазон = CPS ± Jitter.\n0 % — строго постоянный интервал.");
        y += 38;

        if (holdMs is double hold)
        {
            AddLabel(ui.Panel, "Hold, ms", y);
            SetupNumeric(ui.Hold, 266, y, 116, (decimal)hold, (decimal)AppSettings.MinHoldMs, (decimal)AppSettings.MaxHoldMs, 2, 0.05m);
            ui.Panel.Controls.Add(ui.Hold);
            _tips.SetToolTip(ui.Hold, "Сколько мс ЛКМ остаётся нажатой в каждом клике (не зависит от CPS).\nМинимум 0.1 — аналог Click Duty Cycle 0%: клик проходит, а игра почти не успевает увидеть зажатую кнопку и не взаимодействует с блоком.\nЕсли реальный CPS в игре ниже заданного, увеличьте значение.");
            y += 38;
        }

        AddLabel(ui.Panel, "Button", y);
        ui.Bind.SetBounds(266, y - 1, 116, 28);
        StyleButton(ui.Bind);
        ui.Bind.Text = binding.DisplayName;
        ui.Bind.Click += (_, _) => ToggleCapture(channel);
        ui.Panel.Controls.Add(ui.Bind);
        _tips.SetToolTip(ui.Bind, "Нажмите, затем нажмите нужную боковую/среднюю кнопку мыши или клавишу. Esc — отмена.");
        y += 38;

        AddLabel(ui.Panel, "Toggle", y);
        ui.Toggle.Location = new Point(332, y + 1);
        ui.Toggle.BackColor = PanelBg;
        ui.Toggle.Checked = toggle;
        ui.Panel.Controls.Add(ui.Toggle);
        _tips.SetToolTip(ui.Toggle, "Выкл — клики идут, пока кнопка зажата.\nВкл — нажали один раз: клики идут, нажали ещё раз: стоп.");
        y += 38;

        AddLabel(ui.Panel, "Status", y);
        ui.Status.SetBounds(266, y, 116, 26);
        ui.Status.BackColor = Field;
        ui.Status.ForeColor = Muted;
        ui.Status.TextAlign = ContentAlignment.MiddleCenter;
        ui.Status.Text = "WAITING";
        ui.Panel.Controls.Add(ui.Status);
    }

    private static void AddLabel(Panel panel, string text, int y)
    {
        panel.Controls.Add(new Label
        {
            Text = text,
            Location = new Point(12, y + 4),
            AutoSize = true,
            ForeColor = Fg,
            BackColor = PanelBg
        });
    }

    private static void SetupNumeric(NumericUpDown n, int x, int y, int width, decimal value, decimal min, decimal max, int decimals, decimal increment)
    {
        n.SetBounds(x, y, width, 26);
        n.DecimalPlaces = decimals;
        n.Increment = increment;
        n.Minimum = min;
        n.Maximum = max;
        n.Value = Math.Clamp(value, min, max);
        n.TextAlign = HorizontalAlignment.Right;
        n.BackColor = Field;
        n.ForeColor = Fg;
        n.BorderStyle = BorderStyle.FixedSingle;
    }

    private static void StyleButton(Button b)
    {
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderColor = Color.FromArgb(38, 45, 56);
        b.FlatAppearance.BorderSize = 1;
        b.BackColor = Field;
        b.ForeColor = Fg;
        b.UseVisualStyleBackColor = false;
        b.Cursor = Cursors.Hand;
    }

    // ---------------------------------------------------------------- capture of the activation button

    private ChannelUi Ui(int channel) => channel == 0 ? _left : _right;

    private void ToggleCapture(int channel)
    {
        int previous = _capturingChannel;
        if (previous >= 0)
        {
            _hook.CancelCapture();
            _capturingChannel = -1;
            Ui(previous).Bind.Text = Ui(previous).Binding.DisplayName;
            if (previous == channel) return; // a second click on the same button just cancels
        }

        _capturingChannel = channel;
        Ui(channel).Bind.Text = "PRESS KEY…";
        _hook.BeginCapture(binding =>
        {
            try
            {
                if (IsHandleCreated && !IsDisposed) BeginInvoke(() => OnCaptured(channel, binding));
            }
            catch (ObjectDisposedException) { }
            catch (InvalidOperationException) { }
        });
    }

    private void OnCaptured(int channel, ActivationBinding? binding)
    {
        if (_capturingChannel == channel) _capturingChannel = -1;
        var ui = Ui(channel);
        if (binding is not null && binding.IsValid)
        {
            ui.Binding = binding;
            QueueSave();
        }
        ui.Bind.Text = ui.Binding.DisplayName;
    }

    // ---------------------------------------------------------------- apply / save

    private void QueueSave()
    {
        ShowMessage("", false);
        _saveTimer.Stop();
        _saveTimer.Start();
    }

    private (AppSettings? Settings, string? Error) BuildSettings()
    {
        decimal lj = _left.Jitter.Value / 100m;
        decimal rj = _right.Jitter.Value / 100m;
        decimal lMin = _left.Cps.Value * (1m - lj), lMax = _left.Cps.Value * (1m + lj);
        decimal rMin = _right.Cps.Value * (1m - rj), rMax = _right.Cps.Value * (1m + rj);

        if (lMin < 1m || lMax > 50m) return (null, "Left: CPS ± Jitter должен быть в пределах 1–50");
        if (rMin < 1m || rMax > 50m) return (null, "Right: CPS ± Jitter должен быть в пределах 1–50");

        var s = new AppSettings
        {
            MinCps = (double)lMin,
            MaxCps = (double)lMax,
            Binding = _left.Binding,
            LeftToggle = _left.Toggle.Checked,
            LeftHoldMs = (double)_left.Hold.Value,
            RightMinCps = (double)rMin,
            RightMaxCps = (double)rMax,
            RightBinding = _right.Binding,
            RightToggle = _right.Toggle.Checked,
            RequireMinecraftFocus = _current.RequireMinecraftFocus,
            ProcessNames = _current.ProcessNames,
            WindowTitleKeywords = _current.WindowTitleKeywords
        };

        string? error = s.Validate();
        return error is null ? (s, null) : (null, error);
    }

    private void ApplyAndSave()
    {
        var (settings, error) = BuildSettings();
        if (settings is null)
        {
            ShowMessage(error ?? "Некорректные настройки", true);
            return;
        }

        try
        {
            _store.Save(settings);
        }
        catch (Exception ex)
        {
            Logger.Write("Save failed: " + ex);
            ShowMessage("Не удалось сохранить: " + ex.Message, true);
            return;
        }

        _current = settings;
        _leftEngine.Apply(settings); // applied immediately, no restart needed
        _rightEngine.Apply(settings);
        _hook.Apply(settings);
        ShowMessage("Saved", false);
    }

    private void ShowMessage(string text, bool error)
    {
        _msg.Text = text;
        _msg.ForeColor = error ? Error : Muted;
    }

    // ---------------------------------------------------------------- status / closing

    private void UpdateStatus()
    {
        SetStatus(_left.Status, _leftEngine.IsActive);
        SetStatus(_right.Status, _rightEngine.IsActive);
    }

    private static void SetStatus(Label label, bool active)
    {
        string text = active ? "ACTIVE" : "WAITING";
        if (label.Text == text) return;
        label.Text = text;
        label.ForeColor = active ? Green : Muted;
    }

    private void OnFormClosing(object? sender, FormClosingEventArgs e)
    {
        bool pending = _saveTimer.Enabled;
        _saveTimer.Stop();
        _statusTimer.Stop();
        _hook.CancelCapture();
        if (pending) ApplyAndSave();
        _leftEngine.Stop();
        _rightEngine.Stop();
    }
}
