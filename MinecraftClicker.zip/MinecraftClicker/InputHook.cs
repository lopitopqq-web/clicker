using System.Runtime.InteropServices;

namespace MinecraftClicker;

/// <summary>
/// Installs WH_MOUSE_LL / WH_KEYBOARD_LL on its own thread (with its own message loop, so UI stalls cannot
/// delay input processing). Detects press and release of the activation buttons and starts/stops the matching
/// engine (left or right mouse button). An activation button is swallowed only when it actually triggered
/// clicking (so the game never sees it). Injected events (our own SendInput clicks, other tools) are ignored.
/// </summary>
internal sealed class InputHook : IDisposable
{
    private sealed class Channel
    {
        public Channel(ClickEngine engine, ActivationBinding binding)
        {
            Engine = engine;
            Binding = binding;
        }

        public ClickEngine Engine { get; }
        public volatile ActivationBinding Binding;
        public volatile bool Toggle;

        // touched only from the hook thread
        public bool Held;
        public bool HeldToggle;
        public BindingKind HeldKind;
        public int HeldCode;
    }

    private readonly Channel[] _channels;
    private readonly FocusChecker _focus = new();
    private readonly Native.HookProc _mouseProc;
    private readonly Native.HookProc _keyProc;

    private Thread? _thread;
    private uint _threadId;
    private IntPtr _mouseHook;
    private IntPtr _keyHook;
    private volatile bool _installed;
    private bool _disposed;

    private volatile bool _requireFocus = true;
    private Action<ActivationBinding?>? _capture;

    // touched only from the hook thread
    private bool _swallowUpPending;
    private BindingKind _swallowKind;
    private int _swallowCode;

    public InputHook(ClickEngine leftEngine, ClickEngine rightEngine)
    {
        _channels = new[]
        {
            new Channel(leftEngine, ActivationBinding.Default),
            new Channel(rightEngine, new ActivationBinding(BindingKind.Mouse, 2))
        };
        _mouseProc = MouseProc;
        _keyProc = KeyboardProc;
    }

    public void Apply(AppSettings settings)
    {
        _focus.Update(settings.ProcessNames, settings.WindowTitleKeywords);
        _requireFocus = settings.RequireMinecraftFocus;
        _channels[0].Binding = settings.Binding;
        _channels[1].Binding = settings.RightBinding;
        _channels[0].Toggle = settings.LeftToggle;
        _channels[1].Toggle = settings.RightToggle;
    }

    /// <summary>Installs the hooks. Returns false if Windows refused to install them.</summary>
    public bool Start()
    {
        using var ready = new ManualResetEventSlim(false);
        _thread = new Thread(() => ThreadMain(ready))
        {
            IsBackground = true,
            Name = "InputHook",
            Priority = ThreadPriority.AboveNormal
        };
        _thread.Start();
        ready.Wait(5000);
        return _installed;
    }

    /// <summary>The next mouse side/middle button or key press is delivered to the callback (null = cancelled with Esc).</summary>
    public void BeginCapture(Action<ActivationBinding?> callback) => Volatile.Write(ref _capture, callback);

    public void CancelCapture() => Interlocked.Exchange(ref _capture, null);

    private void ThreadMain(ManualResetEventSlim ready)
    {
        try
        {
            _threadId = Native.GetCurrentThreadId();
            Native.PeekMessage(out _, IntPtr.Zero, 0, 0, 0); // make sure the thread has a message queue

            IntPtr module = Native.GetModuleHandle(null);
            _mouseHook = Native.SetWindowsHookEx(Native.WH_MOUSE_LL, _mouseProc, module, 0);
            _keyHook = Native.SetWindowsHookEx(Native.WH_KEYBOARD_LL, _keyProc, module, 0);
            _installed = _mouseHook != IntPtr.Zero && _keyHook != IntPtr.Zero;
            if (!_installed) Logger.Write("SetWindowsHookEx failed, error " + Marshal.GetLastWin32Error());
        }
        catch (Exception ex)
        {
            Logger.Write("Hook install failed: " + ex);
        }
        finally
        {
            ready.Set();
        }

        if (_installed)
        {
            while (Native.GetMessage(out _, IntPtr.Zero, 0, 0) > 0)
            {
                // LL hooks are dispatched from inside GetMessage; nothing else to do.
            }
        }

        if (_mouseHook != IntPtr.Zero) Native.UnhookWindowsHookEx(_mouseHook);
        if (_keyHook != IntPtr.Zero) Native.UnhookWindowsHookEx(_keyHook);
        _mouseHook = _keyHook = IntPtr.Zero;
    }

    private void StopAll()
    {
        foreach (var ch in _channels) ch.Engine.Stop();
    }

    private IntPtr MouseProc(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            try
            {
                int msg = (int)wParam;
                if (msg is Native.WM_MBUTTONDOWN or Native.WM_MBUTTONUP or Native.WM_XBUTTONDOWN or Native.WM_XBUTTONUP)
                {
                    var info = Marshal.PtrToStructure<Native.MSLLHOOKSTRUCT>(lParam);
                    if ((info.flags & Native.LLMHF_INJECTED) == 0)
                    {
                        bool middle = msg is Native.WM_MBUTTONDOWN or Native.WM_MBUTTONUP;
                        int code = middle ? 3 : (int)((info.mouseData >> 16) & 0xFFFF); // 1 = XBUTTON1, 2 = XBUTTON2
                        bool down = msg is Native.WM_MBUTTONDOWN or Native.WM_XBUTTONDOWN;
                        if (Handle(BindingKind.Mouse, code, down)) return (IntPtr)1;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Write("MouseProc: " + ex.Message);
                StopAll();
            }
        }
        return Native.CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
    }

    private IntPtr KeyboardProc(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            try
            {
                int msg = (int)wParam;
                if (msg is Native.WM_KEYDOWN or Native.WM_KEYUP or Native.WM_SYSKEYDOWN or Native.WM_SYSKEYUP)
                {
                    var info = Marshal.PtrToStructure<Native.KBDLLHOOKSTRUCT>(lParam);
                    if ((info.flags & Native.LLKHF_INJECTED) == 0)
                    {
                        bool down = msg is Native.WM_KEYDOWN or Native.WM_SYSKEYDOWN;
                        if (Handle(BindingKind.Key, (int)info.vkCode, down)) return (IntPtr)1;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Write("KeyboardProc: " + ex.Message);
                StopAll();
            }
        }
        return Native.CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
    }

    /// <summary>Returns true if the event must be swallowed.</summary>
    private bool Handle(BindingKind kind, int code, bool down)
    {
        // 1) Capture mode (rebinding). Only presses are captured.
        var capture = Volatile.Read(ref _capture);
        if (capture is not null && down)
        {
            if (Interlocked.CompareExchange(ref _capture, null, capture) == capture)
            {
                _swallowUpPending = true;
                _swallowKind = kind;
                _swallowCode = code;
                bool cancel = kind == BindingKind.Key && code == 0x1B; // Esc
                try { capture(cancel ? null : new ActivationBinding(kind, code)); } catch { }
            }
            return true;
        }

        // 2) Release: matched against what was actually pressed, so changing a binding mid-hold cannot stick.
        if (!down)
        {
            bool swallow = false;
            foreach (var ch in _channels)
            {
                if (ch.Held && kind == ch.HeldKind && code == ch.HeldCode)
                {
                    ch.Held = false;
                    if (!ch.HeldToggle) ch.Engine.Stop(); // in toggle mode the release does nothing
                    swallow = true;
                }
            }
            if (swallow) return true;

            if (_swallowUpPending && kind == _swallowKind && code == _swallowCode)
            {
                _swallowUpPending = false;
                return true;
            }
            return false;
        }

        // 3) Press.
        foreach (var ch in _channels)
        {
            if (ch.Held && kind == ch.HeldKind && code == ch.HeldCode) return true; // key auto-repeat of a held key
        }
        if (_swallowUpPending && kind == _swallowKind && code == _swallowCode) return true; // auto-repeat after capture

        foreach (var ch in _channels)
        {
            var binding = ch.Binding;
            if (binding.Kind != kind || binding.Code != code) continue;
            bool stopping = ch.Toggle && ch.Engine.IsActive; // toggle mode: the second press switches clicking off
            if (!stopping && _requireFocus && !_focus.IsMinecraftFocused()) return false; // not in the game: leave the button alone

            ch.Held = true;
            ch.HeldKind = kind;
            ch.HeldCode = code;
            ch.HeldToggle = ch.Toggle;
            if (stopping) ch.Engine.Stop();
            else ch.Engine.Start();
            return true;
        }
        return false;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        CancelCapture();
        StopAll();

        if (_thread is not null && _threadId != 0)
        {
            Native.PostThreadMessage(_threadId, Native.WM_QUIT, UIntPtr.Zero, IntPtr.Zero);
            if (!_thread.Join(2000)) Logger.Write("InputHook thread did not exit in time");
        }
    }
}
