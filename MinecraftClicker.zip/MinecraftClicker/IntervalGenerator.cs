using System.Security.Cryptography;

namespace MinecraftClicker;

/// <summary>
/// Generates click-to-click intervals (ms) that always stay inside [1000/maxCps, 1000/minCps].
///
/// Model (no fixed delay table, no repeating cycle):
///  - a slowly changing "mood" target mu in [0,1] (re-drawn every 6..25 clicks, triangular distribution);
///  - a position x in [0,1] that is pulled toward mu and perturbed by Gaussian noise every click;
///  - interval = lerp(minMs, maxMs, x) plus ~1.5% Gaussian micro-jitter;
///  - values that leave the allowed range are REFLECTED back (not clamped), so there is no pile-up on the borders.
/// Because of the final reflection every returned value is inside the bounds by construction.
/// When min == max (Jitter 0 %) the interval is strictly constant.
/// Not thread-safe: use from one thread only.
/// </summary>
public sealed class IntervalGenerator
{
    private readonly Random _rng;
    private double _minMs = 1000.0 / 20;
    private double _maxMs = 1000.0 / 17;
    private double _x = 0.5;
    private double _mu = 0.5;
    private int _untilMuChange;
    private bool _fixed;
    private bool _haveSpare;
    private double _spare;

    public double MinIntervalMs => _minMs;
    public double MaxIntervalMs => _maxMs;

    public IntervalGenerator(Random? rng = null)
    {
        _rng = rng ?? new Random(RandomNumberGenerator.GetInt32(int.MaxValue));
        Configure(17, 20);
    }

    public void Configure(double minCps, double maxCps)
    {
        minCps = Math.Clamp(minCps, AppSettings.MinAllowedCps, AppSettings.MaxAllowedCps);
        maxCps = Math.Clamp(maxCps, AppSettings.MinAllowedCps, AppSettings.MaxAllowedCps);
        if (minCps > maxCps) (minCps, maxCps) = (maxCps, minCps);

        double lo = minCps, hi = maxCps;
        _fixed = hi - lo < 1e-9; // Jitter 0 %: strictly constant interval

        _minMs = 1000.0 / hi;
        _maxMs = 1000.0 / lo;
        _untilMuChange = 0;
    }

    /// <summary>
    /// Call at the start of every click session: the first 8..12 clicks are drawn from the fast end of the range
    /// (a sharp start), then the generator relaxes back to its normal behaviour. Bounds are still guaranteed.
    /// </summary>
    public void BeginBurst()
    {
        _x = _rng.NextDouble() * 0.25;
        _mu = _rng.NextDouble() * 0.20;
        _untilMuChange = _rng.Next(8, 13);
    }

    /// <summary>Next interval between the starts of two consecutive clicks, in milliseconds.</summary>
    public double Next()
    {
        if (_fixed) return _minMs;

        if (--_untilMuChange <= 0)
        {
            _mu = (_rng.NextDouble() + _rng.NextDouble()) / 2.0;
            _untilMuChange = _rng.Next(6, 26);
        }

        _x += 0.30 * (_mu - _x) + 0.22 * Gauss();
        _x = Reflect(_x, 0.0, 1.0);

        double v = _minMs + _x * (_maxMs - _minMs);
        v += Gauss() * 0.015 * v;
        return Reflect(v, _minMs, _maxMs);
    }

    /// <summary>How long the virtual button stays down for a click with the given interval (always 0 &lt; hold &lt; interval).</summary>
    public double NextHold(double intervalMs)
    {
        double frac = Reflect(0.35 + 0.08 * Gauss(), 0.20, 0.55);
        return Math.Max(0.5, intervalMs * frac);
    }

    /// <summary>
    /// Press duration in ms, set independently of the interval: the configured value with +-15% jitter,
    /// at least 0.05 ms and never longer than 80% of the interval.
    /// </summary>
    public double NextPulse(double holdMs, double intervalMs)
    {
        double h = holdMs * (0.85 + 0.30 * _rng.NextDouble());
        return Math.Max(0.05, Math.Min(h, intervalMs * 0.8));
    }

    private double Gauss()
    {
        if (_haveSpare)
        {
            _haveSpare = false;
            return _spare;
        }

        double u1;
        do { u1 = _rng.NextDouble(); } while (u1 <= double.Epsilon);
        double u2 = _rng.NextDouble();
        double r = Math.Sqrt(-2.0 * Math.Log(u1));
        _spare = r * Math.Sin(2.0 * Math.PI * u2);
        _haveSpare = true;
        return r * Math.Cos(2.0 * Math.PI * u2);
    }

    internal static double Reflect(double v, double lo, double hi)
    {
        double w = hi - lo;
        if (w <= 0) return lo;
        double p = 2.0 * w;
        double t = (v - lo) % p;
        if (t < 0) t += p;
        if (t > w) t = p - t;
        return lo + t;
    }
}
