using System.Text;

namespace MinecraftClicker;

/// <summary>
/// Automated checks that need no mouse injection. Run: MinecraftClicker.exe --selftest
/// Writes selftest.txt next to the EXE and shows a summary. Exit code 0 = all passed.
/// </summary>
internal static class SelfTest
{
    public static int Run()
    {
        var report = new StringBuilder();
        int failures = 0;

        void Check(string name, bool ok, string detail = "")
        {
            report.AppendLine($"[{(ok ? "OK  " : "FAIL")}] {name} {detail}".TrimEnd());
            if (!ok) failures++;
        }

        // ---- interval generator ----
        var ranges = new (double Min, double Max)[] { (17, 20), (1, 25), (10, 12), (24, 25), (1, 2), (25, 25), (1, 1), (17.5, 17.5), (30, 50), (49, 50), (50, 50) };
        foreach (var (min, max) in ranges)
        {
            const int N = 50_000;
            var gen = new IntervalGenerator(new Random(12345));
            gen.Configure(min, max);

            double expLo, expHi; // expected interval bounds in ms
            if (min < max) { expLo = 1000.0 / max; expHi = 1000.0 / min; }
            else { expLo = expHi = 1000.0 / min; } // Jitter 0 %: constant interval
            bool isFixed = min >= max;

            var v = new double[N];
            double lo = double.MaxValue, hi = double.MinValue, sum = 0;
            for (int i = 0; i < N; i++)
            {
                v[i] = gen.Next();
                lo = Math.Min(lo, v[i]);
                hi = Math.Max(hi, v[i]);
                sum += v[i];
            }

            string tag = $"{min}-{max} CPS";
            Check($"{tag}: bounds respected", lo >= expLo - 1e-9 && hi <= expHi + 1e-9,
                $"(min {lo:F3} ms, max {hi:F3} ms, allowed {expLo:F3}..{expHi:F3})");

            double meanCps = 1000.0 * N / sum;
            Check($"{tag}: average CPS inside range", meanCps >= 1000.0 / expHi - 1e-9 && meanCps <= 1000.0 / expLo + 1e-9,
                $"(avg {meanCps:F2})");

            if (isFixed)
            {
                Check($"{tag}: Jitter 0% gives a strictly constant interval", hi - lo < 1e-6, $"(range {lo:F6}..{hi:F6} ms)");
            }
            else
            {
                var distinct = new HashSet<long>();
                int longestRun = 1, run = 1;
                for (int i = 0; i < N; i++)
                {
                    distinct.Add((long)(v[i] * 1e9));
                    if (i > 0 && Math.Abs(v[i] - v[i - 1]) < 1e-9) { run++; longestRun = Math.Max(longestRun, run); }
                    else run = 1;
                }
                Check($"{tag}: values are not a fixed set", distinct.Count > N * 0.95, $"(distinct {distinct.Count}/{N})");
                Check($"{tag}: no runs of identical delays", longestRun <= 2, $"(longest run {longestRun})");

                int worstPeriod = 0;
                double worstShare = 0;
                for (int p = 1; p <= 64; p++)
                {
                    int same = 0;
                    for (int i = 0; i + p < N; i++) if (Math.Abs(v[i] - v[i + p]) < 1e-9) same++;
                    double share = (double)same / (N - p);
                    if (share > worstShare) { worstShare = share; worstPeriod = p; }
                }
                Check($"{tag}: no repeating pattern (period 1..64)", worstShare < 0.01, $"(worst period {worstPeriod}: {worstShare:P2})");

                double mean = sum / N, variance = 0;
                for (int i = 0; i < N; i++) variance += (v[i] - mean) * (v[i] - mean);
                double stdev = Math.Sqrt(variance / N);
                Check($"{tag}: spread is meaningful", stdev > 0.05 * (expHi - expLo), $"(stdev {stdev:F3} ms of {expHi - expLo:F3} ms range)");
            }

            bool holdOk = true;
            for (int i = 0; i < 5000 && holdOk; i++)
            {
                double interval = gen.Next();
                double hold = gen.NextHold(interval);
                holdOk = hold > 0 && hold < interval;
            }
            Check($"{tag}: hold time always shorter than interval", holdOk);
        }

        // ---- reconfiguration without restart ----
        {
            var gen = new IntervalGenerator(new Random(7));
            gen.Configure(17, 20);
            for (int i = 0; i < 100; i++) gen.Next();
            gen.Configure(5, 6);
            bool ok = true;
            for (int i = 0; i < 1000; i++)
            {
                double x = gen.Next();
                ok &= x >= 1000.0 / 6 - 1e-9 && x <= 1000.0 / 5 + 1e-9;
            }
            Check("live reconfiguration takes effect immediately", ok);
        }

        // ---- press duration is independent of the interval ----
        {
            var gen = new IntervalGenerator(new Random(11));
            bool ok = true;
            double lo = double.MaxValue, hi = double.MinValue;
            var distinct = new HashSet<long>();
            foreach (double configured in new[] { 0.1, 0.2, 5.0, 50.0 })
            {
                foreach (double interval in new[] { 20.0, 55.0, 1000.0 })
                {
                    for (int i = 0; i < 2000; i++)
                    {
                        double h = gen.NextPulse(configured, interval);
                        ok &= h >= 0.05 - 1e-9 && h <= interval * 0.8 + 1e-9;
                        if (configured <= 5.0) ok &= h >= configured * 0.85 - 1e-9 && h <= configured * 1.15 + 1e-9;
                        if (configured == 0.2) { lo = Math.Min(lo, h); hi = Math.Max(hi, h); distinct.Add((long)(h * 1e9)); }
                    }
                }
            }
            Check("press duration: within +-15% of the setting and always shorter than the interval", ok, $"(0.2 ms setting gives {lo:F3}..{hi:F3} ms)");
            Check("press duration: small natural variation", distinct.Count > 100);
        }

        // ---- sharp start ----
        {
            var rng = new Random(99);
            var gen = new IntervalGenerator(rng);
            gen.Configure(17, 20);
            double mid = (gen.MinIntervalMs + gen.MaxIntervalMs) / 2;
            double sumFirst = 0;
            int count = 0;
            bool inBounds = true;
            for (int session = 0; session < 500; session++)
            {
                gen.BeginBurst();
                for (int i = 0; i < 8; i++)
                {
                    double x = gen.Next();
                    inBounds &= x >= gen.MinIntervalMs - 1e-9 && x <= gen.MaxIntervalMs + 1e-9;
                    sumFirst += x;
                    count++;
                }
            }
            Check("sharp start: first clicks come from the fast half of the range", sumFirst / count < mid,
                $"(avg first-8 interval {sumFirst / count:F2} ms, midpoint {mid:F2} ms)");
            Check("sharp start: bounds still respected", inBounds);
        }

        // ---- settings validation ----
        Check("validation: 17..20 accepted", new AppSettings { MinCps = 17, MaxCps = 20 }.Validate() is null);
        Check("validation: min > max rejected", new AppSettings { MinCps = 20, MaxCps = 17 }.Validate() is not null);
        Check("validation: 0 rejected", new AppSettings { MinCps = 0, MaxCps = 10 }.Validate() is not null);
        Check("validation: 51 rejected", new AppSettings { MinCps = 10, MaxCps = 51 }.Validate() is not null);
        Check("validation: up to 50 accepted for both buttons",
            new AppSettings { MinCps = 30, MaxCps = 50, RightMinCps = 40, RightMaxCps = 50 }.Validate() is null);
        Check("validation: NaN rejected", new AppSettings { MinCps = double.NaN, MaxCps = 10 }.Validate() is not null);
        Check("validation: press duration 0.1..50 ms accepted", new AppSettings { LeftHoldMs = 0.1 }.Validate() is null && new AppSettings { LeftHoldMs = 50 }.Validate() is null);
        Check("validation: press duration 0 / 0.05 / 51 / NaN rejected",
            new AppSettings { LeftHoldMs = 0 }.Validate() is not null && new AppSettings { LeftHoldMs = 0.05 }.Validate() is not null
            && new AppSettings { LeftHoldMs = 51 }.Validate() is not null && new AppSettings { LeftHoldMs = double.NaN }.Validate() is not null);
        Check("validation: bad binding rejected", new AppSettings { Binding = new ActivationBinding(BindingKind.Mouse, 9) }.Validate() is not null);
        Check("validation: RMB range accepted", new AppSettings { RightMinCps = 10, RightMaxCps = 12 }.Validate() is null);
        Check("validation: RMB min > max rejected", new AppSettings { RightMinCps = 20, RightMaxCps = 17 }.Validate() is not null);
        Check("validation: RMB out of range rejected", new AppSettings { RightMinCps = 0, RightMaxCps = 17 }.Validate() is not null);
        Check("validation: same button for LMB and RMB rejected",
            new AppSettings { Binding = new ActivationBinding(BindingKind.Mouse, 2), RightBinding = new ActivationBinding(BindingKind.Mouse, 2) }.Validate() is not null);

        // ---- settings persistence ----
        string tmpDir = Path.Combine(Path.GetTempPath(), "MinecraftClickerSelfTest_" + Guid.NewGuid().ToString("N"));
        try
        {
            var store = new SettingsStore(Path.Combine(tmpDir, "settings.json"));
            var saved = new AppSettings
            {
                MinCps = 12.5, MaxCps = 18, Binding = new ActivationBinding(BindingKind.Mouse, 3),
                RightMinCps = 14, RightMaxCps = 16, RightBinding = new ActivationBinding(BindingKind.Mouse, 1),
                LeftHoldMs = 0.35, LeftToggle = true, RightToggle = true
            };
            store.Save(saved);
            var loaded = store.Load();
            Check("persistence: round trip", loaded.MinCps == 12.5 && loaded.MaxCps == 18 && loaded.Binding == saved.Binding,
                $"(loaded {loaded.MinCps}-{loaded.MaxCps}, {loaded.Binding.DisplayName})");
            Check("persistence: RMB round trip", loaded.RightMinCps == 14 && loaded.RightMaxCps == 16 && loaded.RightBinding == saved.RightBinding,
                $"(loaded {loaded.RightMinCps}-{loaded.RightMaxCps}, {loaded.RightBinding.DisplayName})");

            Check("persistence: press duration round trip", loaded.LeftHoldMs == 0.35, $"(loaded {loaded.LeftHoldMs} ms)");
            Check("persistence: toggle options round trip", loaded.LeftToggle && loaded.RightToggle);

            File.WriteAllText(store.FilePath, "{ \"MinCps\": 15, \"MaxCps\": 19, \"Binding\": { \"Kind\": \"Mouse\", \"Code\": 1 } }");
            var old1 = store.Load();
            Check("migration: old file keeps LMB settings, RMB gets defaults",
                old1.MinCps == 15 && old1.MaxCps == 19 && old1.Binding.Code == 1
                && old1.RightMinCps == 17 && old1.RightMaxCps == 20 && old1.RightBinding.Code == 2 && old1.LeftHoldMs == 0.2);

            File.WriteAllText(store.FilePath, "{ \"MinCps\": 15, \"MaxCps\": 19, \"Binding\": { \"Kind\": \"Mouse\", \"Code\": 2 } }");
            var old2 = store.Load();
            Check("migration: old file with LMB on side button 2 is kept, RMB moves to another button",
                old2.MinCps == 15 && old2.MaxCps == 19 && old2.Binding.Code == 2 && old2.RightBinding != old2.Binding && old2.Validate() is null);

            File.WriteAllText(store.FilePath, "{ this is not json");
            var fallback = store.Load();
            Check("persistence: corrupt file falls back to 17..20", fallback.MinCps == 17 && fallback.MaxCps == 20);

            File.WriteAllText(store.FilePath, "{ \"MinCps\": 22, \"MaxCps\": 5 }");
            var invalid = store.Load();
            Check("persistence: invalid values fall back to defaults", invalid.MinCps == 17 && invalid.MaxCps == 20);

            bool threw = false;
            try { store.Save(new AppSettings { MinCps = 20, MaxCps = 17 }); } catch (ArgumentException) { threw = true; }
            Check("persistence: refuses to save invalid settings", threw);
        }
        catch (Exception ex)
        {
            Check("persistence: no exceptions", false, ex.Message);
        }
        finally
        {
            try { Directory.Delete(tmpDir, true); } catch { }
        }

        report.AppendLine();
        report.AppendLine(failures == 0 ? "ALL CHECKS PASSED" : $"{failures} CHECK(S) FAILED");
        report.AppendLine("Not covered here (needs a real Minecraft window): hold/release, focus loss, stuck LMB, closing while clicking. See README.");

        string text = report.ToString();
        try
        {
            string dir = Path.GetDirectoryName(Environment.ProcessPath) ?? Path.GetTempPath();
            File.WriteAllText(Path.Combine(dir, "selftest.txt"), text);
        }
        catch
        {
            File.WriteAllText(Path.Combine(Path.GetTempPath(), "selftest.txt"), text);
        }

        MessageBox.Show(failures == 0 ? "Все проверки пройдены.\nПодробности в selftest.txt рядом с EXE." : $"Провалено проверок: {failures}.\nСмотрите selftest.txt рядом с EXE.",
            "Minecraft Clicker — самопроверка", MessageBoxButtons.OK, failures == 0 ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        return failures == 0 ? 0 : 1;
    }
}
